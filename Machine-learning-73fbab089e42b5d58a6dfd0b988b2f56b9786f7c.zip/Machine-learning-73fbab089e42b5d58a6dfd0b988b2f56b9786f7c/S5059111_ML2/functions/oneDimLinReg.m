function w = oneDimLinReg(x,t)

    w=sum(x.*t) / sum(x.^2);
    
end

