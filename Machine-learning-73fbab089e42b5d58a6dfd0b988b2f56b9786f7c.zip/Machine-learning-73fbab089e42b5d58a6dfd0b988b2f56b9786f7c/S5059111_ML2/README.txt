                                                     MACHINE LEARNING ASSIGNMENT 2
                                                      YESHWANTH GURU KRISHNAKUMAR 
                                                              S5059111
This file is to address and describe the data of my assignment content


data - This file contains the data to load.
function -matlab files for the functions.
outputfiles-output data in plotted view.
output images-output data in jpeg format.
mainfile-overall meta
README-data description
S5059111_ml2_report-Assignment 2 overall report in pdf.



